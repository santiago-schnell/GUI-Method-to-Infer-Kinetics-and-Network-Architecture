function [used_reactions predicted_reactions diff_equations Errors] = spec_main_mts_randa(x, D, filename, ICselection, Bimolecular, Molecules)

% Spec_main_mts_rand - Spec main function specially modified for taking in mts - multiple time series generated using
% random initial conditions.
% This program simply takes in the time series and the derivative matrix
% and passed it to the G2S algorithm.
% Finally the results of the G2s algorithm are fed into recondes algorithm
% to obtain differential equations and subsequent index arrays to determine
% sensitivities or accuracy of the run.

used_reactions={};
predicted_reactions={};
diff_equations={};
Errors=[];

[NN,MM] = size(x);

%%%% change to concatenated vector format
for i=1:MM
  y(1+(i-1)*NN:i*NN,1)=D(:,i);
end

[A,index,nindex] = mdm_g2s_mts_rand(x, Bimolecular, Molecules); % set up model design matrix

% remove extra columns from A, index and nindex
[ils ics]=size(index);
remov=[];
for i=1:ics
   if (sum(index(:,i))==0)
       remov(length(remov)+1)=i;
   end
end

A(:,remov)=[];
index(:,remov)=[];
nindex(:,remov)=[];

% the reactions to remove are optional
if not(strcmp(filename,''))
    [X,index,nindex] = filter_reactions(A, index, nindex, filename); % filter reactions
else
    X=A;
end

[inn,imm] = size(index);
if (imm==0) return; end;

% build used reactions
for j=1:imm
    used_reactions{j}=sprintf('%i: %i X[%i] + %i X[%i] -> %i X[%i] + %i X[%i]',...
        j,nindex(1,j),index(1,j),nindex(2,j),index(2,j),...
        nindex(3,j),index(3,j),nindex(4,j),index(4,j));
end


[indg2s,ag2s,Errors] = genspec2_randa(X, y, ICselection, MM);

if isempty(indg2s) return; end;

% build predicted reactions
pos=0;
for j=1:imm
  if (find(indg2s==j))
      pos=pos+1;
      predicted_reactions{pos}=sprintf('%i: %i X[%i] + %i X[%i] -> %i X[%i] + %i X[%i]',...
          j,nindex(1,j),index(1,j),nindex(2,j),index(2,j),...
          nindex(3,j),index(3,j),nindex(4,j),index(4,j));
  end
end

% reconstruct differential equations
[SS,cg2s,diff_equations] = recondes_g2s_express_rand(ag2s,indg2s,index,nindex,MM);


