function [ind, a, Errors] = genspec2_randa(X, y, ICselection, NSpecies)
% [ind, a] = gen2spec(y, X) selects variables from the columns of X for
% giving a function fit of the form y = X(:,ind) a, which minimises the
% an Information Criterion (AIC). Both the indices of the columns, ind,
% and the model parameters, a, are returned. A general to specific approach
% is employed while the minimum AIC cost function is sought.

ind=[];
a=[];
Errors=[];

% normalise all bases
[N,M] = size(X);
xnorm = sqrt(sum(X.^2));
Xnorm = ones(N,1)*xnorm;
V = X./Xnorm;

% calculate general model
ind = [1:M];
a = lsqnonneg(V,y);
[ind] = find(a~=0);
Vb = V(:,ind);
a = a(ind);
yh = Vb*a;
E = yh - y;

k = length(ind);
if (k==0) return; end;

Ms = sum(E.^2)/(length(E)-k);
S(k) = penalty(E,k,ICselection);
Sold = S(k)+ 1;
indopt=ind;

%*******************************************************************
%Main Loop
%*******************************************************************
% drop bases until optimal model is found
while ((k>1) && (S(k) < Sold)),
    indopt = ind;
    kopt = k;
    [ind, E] = dropanother(y, V, ind);
    k = k-1;
    S(k) = penalty(E, k, ICselection);
    Sold = S(k+1);
end

ind = indopt;
Vb = X(:,ind);
a = lsqnonneg(Vb,y);
yh = Vb*a;
e = (yh - y);
len=length(e);
dataPoints=len/NSpecies;

for i=1:NSpecies
    Errors(i)=mean(e((i-1)*dataPoints+1:i*dataPoints,:).^2);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [ind1, E] = dropanother(y, V, ind)
k = length(ind);

%Finding the basis function that causes least error when removed

for i=1:k
    ind0 = ind([1:i-1 i+1:k]);
    Vb = V(:,ind0);
    a = lsqnonneg(Vb,y);
    yh = Vb*a;
    e = (yh - y);
    E0(i) = mean(e.^2);
end

[E0min,imin] = min(E0);
ind1 = ind([1:imin-1 imin+1:k]);
Vb = V(:,ind1);
a = lsqnonneg(Vb,y);
yh = Vb*a;
E = yh - y;

%fprintf(1,'dropping (%i) from basis\n',ind(imin));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

