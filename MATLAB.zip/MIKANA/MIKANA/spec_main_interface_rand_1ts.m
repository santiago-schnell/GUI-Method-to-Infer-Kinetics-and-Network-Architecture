
function [XX, VV] = spec_main_interface_rand_1ts(T, Y)
% Interpolating and finding derivatives by forward difference method.

% Other variable settings
n_of_ts = 1; % we are just using one time series
tp=length(Y{1});

k = 1;
[iy,ij] = size(Y{1});
X = zeros(tp-1, ij, n_of_ts);

for i = 1:n_of_ts
    t = T{i};
    y = Y{i};
    l1 = length(t);
    newt = linspace(0,t(l1),tp);
    newy = interp1(t,y,newt,'spline');
    newt = newt';
    [P,N] = size(newy);
    M = P-1;
    dt = diff(newt);
    t = newt(1:M) + 0.5*dt;
    dxdt0 = diff(newy)./(dt*ones(1,N));
    
    for ii=1:N
        x0(:,ii) = interp1(newt,newy(:,ii),t);
    end
    
    XX(:,:,k) = x0;
    VV(:,:,k) = dxdt0;
    k = k+1;
end

clear newt newy dxdt t dt M P N x0 dxdt0 i j y newY
