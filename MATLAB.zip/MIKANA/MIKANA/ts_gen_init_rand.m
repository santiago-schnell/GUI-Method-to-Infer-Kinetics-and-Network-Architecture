function [newt, newy] = ts_gen_init_rand(t,y)

%This file generates time series for Michaelis_menten reaction. Each time
% a random initial condition is chosen and time series is generated. This
% file can be used to generate a command line variable input to MIKANA.

%high resolution time span

tspan = 0:0.2:1200;

%Random initial conditions rounded off to first decimal
% 
% a = 0.25; b = 4;
% init = a + (b-a) * rand(2,1);
% init = round(init*1000)/1000;
% init = init';

init(1) = y(1,1);
init(2) = y(1,2);

% Solve the DEs for EK

%[t,y] = ode15s('michaelis_menten',tspan,[init 0 0]);
%plot(t,y)
%Breaks where the steady state is achieved

l = length(y);
for i = 2:l
    if (init(1) > init(2)) && ((y(i,2) > y(i-1,2)) && y(i,2)>= 0.85*init(2))
        endpoint = i;
        break
    elseif (init(2) > init(1)) && (y(i,1) <= 0.03*init(1))
        endpoint = i;
        break
    elseif (init(2) == init(1)) && (y(i,1) <= 0.03*init(1))
        endpoint = i;
        break
    end
end

%Redefining t and y

t = t(1:endpoint);
y = y(1:endpoint,:);
l1 = length(y);
newt = t;
newy = y;
%t(endpoint)
%endpoint
%Breaking the no. of data points
np = 50;
newt = linspace(0,t(l1),np);
newy = interp1(t,y,newt,'spline');
newt = newt';