
function C = penalty(E, k, ICselection)
N = length(E);
if (strcmp(ICselection,'Empirical'))
      C = sum(E.^2) + k;
elseif (strcmp(ICselection,'Akaike'))
      C =  N*log(mean(E.^2)) + 2*k;
elseif (strcmp(ICselection,'Bayesian'))
      C = N*log(mean(E.^2)) + k*log(N);
end
