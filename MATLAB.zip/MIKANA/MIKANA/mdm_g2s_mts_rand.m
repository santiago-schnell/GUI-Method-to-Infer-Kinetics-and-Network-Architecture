function [A,index,nindex] = mdm_g2s_mts_rand(x, Bimolecular, Molecules)

[M,N] = size(x);
A0 = zeros(N*M,1);

%preallocating size of A

if N == 4
    A = zeros(N*M,44);
    index = zeros(4,44);
    nindex = zeros(4,44);
elseif N == 5
    A = zeros(N*M,90);
    index = zeros(4,90);
    nindex = zeros(4,90);
elseif N == 6
    A = zeros(N*M,162);
    index = zeros(4,162);
    nindex = zeros(4,162);
elseif N == 7
    A = zeros(N*M,266);
    index = zeros(4,266);
    nindex = zeros(4,266);
end

vel=ones(M,1);
ind = 0;

%%%ZERO LHS (only need to consider each variable separately for RHS)
for i=1:N
    ind=ind+1;
    A(:,ind)=A0;
    A(1+(i-1)*M:i*M,ind)=vel(:);   %constant source terms for each species
    index(:,ind) = [0;0;i;0];
    nindex(:,ind) = [0;0;1;0];
end

%%%SINGLETON LHS
for i=1:N
    for ni=1:Molecules %no pure cubics
        vel(:) = (x(:,i).^ni);
        % --> ZERO
        if ni==1 %unimolecular sink terms only
            ind=ind+1;
            A(:,ind)=A0;
            A(1+(i-1)*M:i*M,ind)=-ni*vel(:);
            index(:,ind) = [i;0;0;0];
            nindex(:,ind) = [ni;0;0;0];
        end
        %A

        % --> SINGLETON
        for l=1:N  %
            for nl=1:Molecules
                %if ~(l==i && nl==ni)
                if ~(l==i)%no pure changes of molecularity
                    ind=ind+1;
                    A(:,ind)=A0;
                    A(1+(i-1)*M:i*M,ind)=-ni*vel(:);
                    A(1+(l-1)*M:l*M,ind)=nl*vel(:);
                    index(:,ind) = [i;0;l;0];
                    nindex(:,ind) = [ni;0;nl;0];
                end
            end
        end
        %    A
        % --> PAIRWISE - include sum of squares terms. No pure cubics.
        if Bimolecular
            for l=1:N
                for m=l+1:N
                    for nl=1:Molecules
                        for nm = 1:Molecules
                            if ~(l==i && nl>=ni) && ~(m==i && nm>=ni) ... %no identities
                                    %                   && nl+nm<=3                    %no wild number changes
                                ind=ind+1;
                                A(:,ind)=A0;
                                A(1+(i-1)*M:i*M,ind)=-ni*vel(:);
                                A(1+(l-1)*M:l*M,ind)=nl*vel(:);
                                A(1+(m-1)*M:m*M,ind)=nm*vel(:);
                                index(:,ind) = [i;0;l;m];
                                nindex(:,ind) = [ni;0;nl;nm];
                            end
                        end
                    end
                end
            end
        end

    end %ni=1:2
end %i=1:N

%%%PAIRWISE LHS
if Bimolecular
    for i=1:N
        for j=i+1:N
            for ni=1:Molecules
                nj=1;
                while ni+nj <= 2 %&& nl+nm <=2% bimolecular at most.
                    vel(:) = (x(:,i).^ni).*(x(:,j).^nj);
                    % --> ZERO RHS %unimolecular sink terms only
                    %ind=ind+1;
                    %A(:,ind)=A0;
                    %A(1+(i-1)*M:i*M,ind)=-ni*vel(:);
                    %A(1+(j-1)*M:j*M,ind)=-nj*vel(:);
                    %index(:,ind) = [i;j;0;0];
                    %nindex(:,ind) = [ni;nj;0;0];
                    
                    % --> SINGLETON
                    for l=1:N
                        for nl=1:Molecules
                            % nl=1;
                            if ~(l==i && nl<=ni) && ~(l==j && nl<=nj) %no identities
                                ind=ind+1;
                                A(:,ind)=A0;
                                A(1+(i-1)*M:i*M,ind)=-ni*vel(:);
                                A(1+(j-1)*M:j*M,ind)=-nj*vel(:);
                                A(1+(l-1)*M:l*M,ind)=nl*vel(:);
                                index(:,ind) = [i;j;l;0];
                                nindex(:,ind) = [ni;nj;nl;0];
                            end
                            
                            
                        end
                    end
                    
                    % --> PAIRWISE - include sum of squares terms. No pure cubics.
                    for l=1:N
                        for m=l+1:N
                            for nl=1:Molecules
                                for nm = 1:Molecules
                                    if ~(l==i && nl<=ni) && ~(l==j && nl<=nj) &&...
                                            ~(m==i && nm<=ni) && ~(m==j && nm<=nj) && ~(nl == nm)%no identities
                                        ind=ind+1;
                                        A(:,ind)=A0;
                                        A(1+(i-1)*M:i*M,ind)=-ni*vel(:);
                                        A(1+(j-1)*M:j*M,ind)=-nj*vel(:);
                                        A(1+(l-1)*M:l*M,ind)=nl*vel(:);
                                        A(1+(m-1)*M:m*M,ind)=nm*vel(:);
                                        index(:,ind) = [i;j;l;m];
                                        nindex(:,ind) = [ni;nj;nl;nm];
                                    end
                                end
                            end
                        end
                    end
                    
                    nj=nj+1;
                end %while ni+nj<=2
            end %ni=1:2
        end %j=i+1:N
    end %i=1:N
end
