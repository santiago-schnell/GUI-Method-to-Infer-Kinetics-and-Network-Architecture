function [A,index,nindex] = filter_reactions(A,index,nindex,filename)

% Opens the file with name 'filename'
fid = fopen(filename,'r');
if (fid==-1)
    return;
end

% this functions obtains the position of an element in a cell
    function pos=getPos(matchstr,ch)
        for pos=1:length(matchstr)
            if (strcmp(matchstr{pos},ch))
                break;
            end
        end
    end

ind=0;
molecs_total=[];
specs_total=[];
while 1
    tline = fgetl(fid);
    if ~ischar(tline) break; end;
    if ~strcmp(tline,'')
        ind=ind+1;
        molecs=ones(4,1); % for the molecules
        specs=zeros(4,1); % for the species
        new_line=regexprep(tline,'[\s]','');
        new_line=upper(new_line);
        [matchstr splitstr] = regexp(new_line, '[-> X +]', 'match', 'split');
        pos=getPos(matchstr,'>');
        elms_react=pos-1;
        elms_prod=length(splitstr)-pos;

        if ((elms_react==2) || (elms_react==4))
            if (not(strcmp(splitstr{1},''))) molecs(1,1)=str2num(splitstr{1}); else molecs(1,1)=-1; end;
            if (not(strcmp(splitstr{2},''))) specs(1,1)=str2num(splitstr{2}); else specs(1,1)=-1; end;
            if (elms_react==4)
                if (not(strcmp(splitstr{3},''))) molecs(2,1)=str2num(splitstr{3}); else molecs(2,1)=-1; end;
                if (not(strcmp(splitstr{4},''))) specs(2,1)=str2num(splitstr{4}); else specs(2,1)=-1; end;
            end
        end

        if ((elms_prod==2) || (elms_prod==4))
            if (not(strcmp(splitstr{pos+1},''))) molecs(3,1)=str2num(splitstr{pos+1}); else molecs(3,1)=-1; end;
            if (not(strcmp(splitstr{pos+2},''))) specs(3,1)=str2num(splitstr{pos+2}); else specs(3,1)=-1; end;
            if (elms_prod==4)
                if (not(strcmp(splitstr{pos+3},''))) molecs(4,1)=str2num(splitstr{pos+3}); else molecs(4,1)=-1; end;
                if (not(strcmp(splitstr{pos+4},''))) specs(4,1)=str2num(splitstr{pos+4}); else specs(4,1)=-1; end;
            end
        end

% When a species appears alone in either side of the reaction, we assume it
% will appear in the first position (first or third line of the reaction
% vector. If not, we may need the following code!
%
%         if (elms_react==2)
%             ind=ind+1;
%             molecs(:,2)=molecs(:,1);
%             specs(:,2)=specs(:,1);
%             molecs(1,2)=molecs(2,1); molecs(2,2)=molecs(1,1);
%             specs(1,2)=specs(2,1); specs(2,2)=specs(1,1);
%         end
%         if (elms_prod==2)
%             [l c]=size(molecs);
%             for i=1:c
%                 ind=ind+1;
%                 molecs(:,c+i)=molecs(:,i);
%                 specs(:,c+i)=specs(:,i);
%                 molecs(3,c+i)=molecs(4,i); molecs(4,c+i)=molecs(3,i);
%                 specs(3,c+i)=specs(4,i); specs(4,c+i)=specs(3,i);
%             end
%         end

        molecs_total=[molecs_total molecs];
        specs_total=[specs_total specs];
    end

end

fclose(fid);

% identify reactions to remove
[B,C] = size(specs_total);
[D,E] = size(index);

rem = [];
for i=1:C % cycle through the reactions
    for j=1:E % cycle through the index
        brem=1;
        k=1;
        while ((k <= 4) && brem) % cycle through the indices of one reaction
            nin=nindex(k,j);
            mt=molecs_total(k,i);
            in=index(k,j);
            st=specs_total(k,i);
            if ~ ( ((in==0) && (st==0)) || ((in>0) && ((nin==mt) || (mt==-1)) && ((in==st) || (st==-1))))
                brem=0;
            end
            k = k + 1;
        end
        if (brem)
            rem = [rem j];
        end
    end
end

%remove reactions
j=1;
in=0;
for i=1:E
 if ~(rem==i)
   new_A(:,j)=A(:,i);
   new_index(:,j)=index(:,i);
   new_nindex(:,j)=nindex(:,i);
   j=j+1;
   in=1;
 end
end

if in
    A = new_A;
    index = new_index;
    nindex = new_nindex;
else
    A=[];
    index=[];
    nindex=[];
end

end

