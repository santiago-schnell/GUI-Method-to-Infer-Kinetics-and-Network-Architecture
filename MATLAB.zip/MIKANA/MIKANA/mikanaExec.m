function [used_reactions predicted_reactions diff_equations Errors] = mikanaExec(T, Y, filename, ICselection, Bimolecular, Molecules)

% Main calls
[XX, VV] = spec_main_interface_rand_1ts(T, Y);
[used_reactions predicted_reactions diff_equations Errors] = spec_main_mts_randa(XX, VV, filename, ICselection, Bimolecular, Molecules);
end