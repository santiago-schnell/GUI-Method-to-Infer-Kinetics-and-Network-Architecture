function [SS,k,express] = recondes_g2s_express_rand(a, indices, index, nindex, S)

N = length(indices);

%%if you want to sort out order of indices
[inds,ii]=sort(indices);

for i=1:1
    for j=1:N
        p=inds(j);
        q=ii(j);
        %%uncheck if you don't want indices sorted
        %p=indices(j);
        %q=j;
        %fprintf(fid,'%i x[%i] + %i x[%i] -> %i x[%i] + %i x[%i],  k=%7.4f,  using basis function (%i)\n',nindex(1,p),index(1,p),nindex(2,p),index(2,p),nindex(3,p),index(3,p),nindex(4,p),index(4,p),a(q),p);
    end
    %fprintf(fid,'\n');

    %%number of species S
    k = zeros(S,S+1,3,S+1,3);

    for p=1:S
        %S1 = zeros(5,3);
        %%matrix of all indexes in the model
        indexm = index(:,indices);
        %%matrix of all nindexes in the model
        nindexm = nindex(:,indices);

        %%find location of terms involving Xp in the model index matrix
        [pr,pc]=find(index(:,indices)==p);
        %% equiv [pr,pc]=find(indexm==p)
        %%number of occurrences
        lenpc= length(pc);

        %%each time Xp crops up need to store a term so to add together
        %%all terms with same Xr^nr.Xs^ns
        %%use r,nr,s,ns as location for array k, but must add 1 to avoid
        %%'0' location.
        for i=1:lenpc
            r = indexm(1,pc(i));
            nr = nindexm(1,pc(i));
            s = indexm(2,pc(i));
            ns = nindexm(2,pc(i));
            %%determine whether Xp is on LHS or RHS to calc sign of term
            %%i.e. negative if p is in the first two rows (LHS terms) and
            %%positive otherwise.
            %%(this assumes we are working with pairwise combinations of X's)
            sgn = sign(pr(i)-2.5);
            rate = a(pc(i))*nindexm(pr(i),pc(i));
            k(p,r+1,nr+1,s+1,ns+1)=k(p,r+1,nr+1,s+1,ns+1)+sgn*rate;
        end

        %%find nonzero elements of k-array
        expr = ['dX(' num2str(p) ') ='];

        %%go through r,nr,s,ns one by one and find nonzero entries
        %%can't do with 'find' as I don't see how to index a 4d cell
        %%array from a single index number (which is what matlab returns)
        h = 0;
        for nr=0:2
            for ns=0:2
                for r=0:S
                    for s=0:S
                        kinc = k(p,r+1,nr+1,s+1,ns+1);
                        if r==0 && s~=0
                            ex = sprintf('%6.4f*X(%i)^%i',abs(kinc),s,ns);
                            if (abs(kinc)>0.00009)
                                h = h+1;
                                S1(h,1) = p;
                                S1(h,2) = 0;
                                S1(h,3) = s;
                            end
                        elseif s==0 && r~=0
                            ex = sprintf('%6.4f*X(%i)^%i',abs(kinc),r,nr);
                            if (abs(kinc)>0.00009)
                                h = h+1;
                                S1(h,1) = p;
                                S1(h,3) = 0;
                                S1(h,2) = r;
                            end
                        elseif r==0 && s==0
                            ex = sprintf('%6.4f',kinc);
                            if(abs(kinc)>0.00009)
                                h = h+1;
                                S1(h,1) = p;
                                S1(h,2) = 0;
                                S1(h,3) = 0;
                            end
                        else
                            ex = sprintf('%6.4f*X(%i)^%i*X(%i)^%i',abs(kinc),r,nr,s,ns);
                            if (abs(kinc)>0.00009)
                                h = h+1;
                                S1(h,1) = p;
                                S1(h,3) = s;
                                S1(h,2) = r;
                            end
                        end

                        if kinc > 0
                            expr = [expr ' + ' ex];
                        elseif kinc < 0
                            expr = [expr ' - ' ex];
                        end
                    end
                end
            end
        end

        if (length(char(expr)) < 12)
            expr = [expr ' 0 '];
            S1 = 0;
        end
        express(p,1) = {expr};
        SS{p} = S1;
        S1 = 0;
    end

end


