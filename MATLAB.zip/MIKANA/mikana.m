function mikana

%Add a path to MIKANA with the source files
addpath MIKANA

%Redefines the window close event
set(0,'DefaultFigureCloseRequestFcn',@my_closereq);

% ----- establishes the figure -----

fig = figure('MenuBar','none','Name','MIKANA Graphical User Interface (Version 1.0)','NumberTitle','off','Position',[300 100 850 1000]);

% ----- establishes the panels -----

%Build a Panel inside figure, value of Position is from 0-1 (1=size of figure), parent for other GUI elements
hpanel = uipanel(fig,'Position',[0 0 1 1]);

% ----- Input

input = uipanel('Parent',hpanel,'Title','INPUT','FontSize',12,'FontWeight','Bold','Position',[.01 .5 .98 .48]);

%Build subpanel as a child of, value of Position is from 0-1 (1=size of hpanel)
hsp1 = uipanel('Parent',input,'Title','Time Course Data','FontSize',12,'FontWeight','Bold','Position',[.01 .01 .4 .98]);

%Build subpanel as a child of, value of Position is from 0-1 (1=size of hpanel)
hsp2 = uipanel('Parent',input,'Title','Non-Possible Reactions','FontSize',12,'FontWeight','Bold','Position',[.71 .01 .28 .485]);

%Build subpanel as a child of, value of Position is from 0-1 (1=size of hpanel)
hsp3 = uipanel('Parent',input,'Title','Information Criteria','FontSize',12,'FontWeight','Bold','Position',[.41 .50 .30 .49]);

%Build subpanel as a child of, value of Position is from 0-1 (1=size of hpanel)
hsp8 = uipanel('Parent',input,'Title','Reaction Order','FontSize',12,'FontWeight','Bold','Position',[.71 .50 .28 .49]);

%Build subpanel as a child of, value of Position is from 0-1 (1=size of hpanel)
hsp9 = uipanel('Parent',input,'Title','Molecularity','FontSize',12,'FontWeight','Bold','Position',[.41 .01 .30 .485]);

% ----- Main

main = uipanel('Parent',hpanel,'Title','MAIN','FontSize',12,'FontWeight','Bold','Position',[.705 .01 .285 .48]);

% ----- Output

output = uipanel('Parent',hpanel,'Title','OUTPUT','FontSize',12,'FontWeight','Bold','Position',[.01 .01 .695 .48]);

%Build subpanel as a child of, value of Position is from 0-1 (1=size of hpanel)
hsp4 = uipanel('Parent',output,'Title','Used Reactions','FontSize',12,'FontWeight','Bold','Position',[.01 .01 .57 .98]);

%Build subpanel as a child of, value of Position is from 0-1 (1=size of hpanel)
hsp5 = uipanel('Parent',output,'Title','Predicted Reactions','FontSize',12,'FontWeight','Bold','Position',[.58 .50 .41 .49]);

%Build subpanel as a child of, value of Position is from 0-1 (1=size of hpanel)
hsp6 = uipanel('Parent',output,'Title','Differential Equations','FontSize',12,'FontWeight','Bold','Position',[.58 .01 .41 .485]);

%Build subpanel as a child of, value of Position is from 0-1 (1=size of hpanel)
%hsp7 = uipanel('Parent',output,'Title','Errors','FontSize',12,'FontWeight','Bold','Position',[.71 .50 .285 .49]);

% ----- establishes the Menu controls -----

% m = uimenu('Label','&File');
% uimenu(m,'Label','New','Callback','gui08');
% uimenu(m,'Label','New Figure','Callback','figure');
% uimenu(m,'Label','Quit','Callback','close','Separator','on','Accelerator','Q');
%
% m = uimenu('Label','&Edit');
% uimenu(m,'Label','&Undo');
% uimenu(m,'Label','&Redo');
% uimenu(m,'Label','&Find','Separator','on');
% uimenu(m,'Label','&Replace');
%
% m = uimenu('Label','&Help');
% uimenu(m,'Label','Help','Callback', @NotImplemented);
% uimenu(m,'Label','About','Separator','on','Callback', @About);

% Global Variables
header={};
T{1}='';
Y{1}='';
TR='';
YR='';
File1='';
File2='';
used_reactions={'','',''};
used_reactions_index=1;
predicted_reactions={'','',''};
predicted_reactions_index=1;
diff_equations={'','',''};
diff_equations_index=2;
Errors='';
ICselection='';
Bimolecular=0;
Molecules=1;
NSpecies=0;

% ----- establishes the Button controls -----

% -------------------------- Input -----------------------------

uicontrol(hsp1,...
    'Style','PushButton',...
    'Units','normalized',...
    'String','Read File',...
    'Position',[0.03,0.87,0.23,0.10],...
    'CallBack',{@open_Callback,1});

uicontrol(hsp1,...
    'Style','PushButton',...
    'Units','normalized',...
    'String','Plot Data',...
    'Position',[0.26,0.87,0.23,0.10],...
    'CallBack',{@plotInputSpeciesVSTime_Button});

uicontrol(hsp1,...
    'Style','PushButton',...
    'Units','normalized',...
    'String','Clean',...
    'Position',[0.49,0.87,0.23,0.10],...
    'CallBack',{@cleanTimeCourseData});

uicontrol(hsp1,...
    'Style','PushButton',...
    'Units','normalized',...
    'String','About',...
    'Position',[0.72,0.87,0.23,0.10],...
    'CallBack',{@aboutTimeCourseData});

timecourse = uicontrol(hsp1,...
    'Units','normalized',...
    'Position',[0.03,0.03,0.94,0.82],...
    'Style','edit',...
    'Max',100,...
    'Enable','inactive',...
    'String','');

% -----

uicontrol(hsp2,...
    'Style','PushButton',...
    'Units','normalized',...
    'String','Read File',...
    'Position',[0.05,0.87,0.30,0.10],...
    'CallBack',{@open_Callback,2});

uicontrol(hsp2,...
    'Style','PushButton',...
    'Units','normalized',...
    'String','Clean',...
    'Position',[0.35,0.87,0.30,0.10],...
    'CallBack',{@cleanReactionsData});

uicontrol(hsp2,...
    'Style','PushButton',...
    'Units','normalized',...
    'String','About',...
    'Position',[0.65,0.87,0.30,0.10],...
    'CallBack',{@aboutReactionsData});

reactions = uicontrol(hsp2,...
    'Units','normalized',...
    'Position',[0.05,0.03,0.9,0.82],...
    'Style','edit',...
    'Max',100,...
    'Enable','inactive',...
    'String','');

% -----

uicontrol(hsp3,...
    'Style','PushButton',...
    'Units','normalized',...
    'String','About',...
    'Position',[0.65,0.87,0.30,0.10],...
    'CallBack',{@aboutIC});

p = uibuttongroup(hsp3,...
    'Units','normalized',...
    'Position',[0.05,0.03,0.9,0.82]);

p1=uicontrol('Style','RadioButton',...
    'Units','normalized',...
    'String','Empirical',...
    'Position',[0.05,0.65,0.50,0.20],...
    'Parent',p);

p2=uicontrol('Style','RadioButton',...
    'Units','normalized',...
    'String','Akaike',...
    'Position',[0.05,0.45,0.50,0.20],...
    'Parent',p);

uicontrol('Style','RadioButton',...
    'Units','normalized',...
    'String','Bayesian',...
    'Position',[0.05,0.25,0.50,0.20],...
    'Parent',p);

% -----

uicontrol(hsp8,...
    'Style','PushButton',...
    'Units','normalized',...
    'String','About',...
    'Position',[0.65,0.87,0.30,0.10],...
    'CallBack',{@aboutInteract});

pp = uibuttongroup(hsp8,...
    'Units','normalized',...
    'Position',[0.05,0.03,0.9,0.82]);

pp1=uicontrol('Style','RadioButton',...
    'Units','normalized',...
    'String','First Order',...
    'Position',[0.05,0.65,0.50,0.20],...
    'Parent',pp);

uicontrol('Style','RadioButton',...
    'Units','normalized',...
    'String','Second Order',...
    'Position',[0.05,0.45,0.50,0.20],...
    'Parent',pp);

% -----

uicontrol(hsp9,...
    'Style','PushButton',...
    'Units','normalized',...
    'String','About',...
    'Position',[0.65,0.87,0.30,0.10],...
    'CallBack',{@aboutMolec});

ppp = uibuttongroup(hsp9,...
    'Units','normalized',...
    'Position',[0.05,0.03,0.9,0.82]);

ppp1=uicontrol('Style','RadioButton',...
    'Units','normalized',...
    'String','Uni-Molecular',...
    'Position',[0.05,0.65,0.50,0.20],...
    'Parent',ppp);

uicontrol('Style','RadioButton',...
    'Units','normalized',...
    'String','Bi-Molecular',...
    'Position',[0.05,0.45,0.50,0.20],...
    'Parent',ppp);

% -------------------------- Output -----------------------------

uicontrol(hsp4,...
    'Style','PushButton',...
    'Units','normalized',...
    'String','Change View',...
    'Position',[0.03,0.87,0.30,0.10],...
    'CallBack',{@changeViewUsedReactions});

uicontrol(hsp4,...
    'Style','PushButton',...
    'Units','normalized',...
    'String','Clean',...
    'Position',[0.34,0.87,0.30,0.10],...
    'CallBack',{@cleanUsedReactions});

uicontrol(hsp4,...
    'Style','PushButton',...
    'Units','normalized',...
    'String','About',...
    'Position',[0.65,0.87,0.30,0.10],...
    'CallBack',{@aboutUsedReactions});

usedreactions = uicontrol(hsp4,...
    'Units','normalized',...
    'Position',[0.03,0.03,0.94,0.82],...
    'Style','edit',...
    'Max',100,...
    'Enable','inactive',...
    'String','');

% -----

uicontrol(hsp5,...
    'Style','PushButton',...
    'Units','normalized',...
    'String','Change View',...
    'Position',[0.05,0.87,0.30,0.10],...
    'CallBack',{@changeViewPredictedReactions});

uicontrol(hsp5,...
    'Style','PushButton',...
    'Units','normalized',...
    'String','Clean',...
    'Position',[0.35,0.87,0.30,0.10],...
    'CallBack',{@cleanPredictedReactions});

uicontrol(hsp5,...
    'Style','PushButton',...
    'Units','normalized',...
    'String','About',...
    'Position',[0.65,0.87,0.30,0.10],...
    'CallBack',{@aboutPredictedReactions});

predictedreactions = uicontrol(hsp5,...
    'Units','normalized',...
    'Position',[0.05,0.03,0.9,0.82],...
    'Style','edit',...
    'Max',100,...
    'Enable','inactive',...
    'String','');

% -----

uicontrol(hsp6,...
    'Style','PushButton',...
    'Units','normalized',...
    'String','Change View',...
    'Position',[0.05,0.87,0.30,0.10],...
    'CallBack',{@changeViewDiffEquations});


uicontrol(hsp6,...
    'Style','PushButton',...
    'Units','normalized',...
    'String','Clean',...
    'Position',[0.35,0.87,0.30,0.10],...
    'CallBack',{@cleanDiffEquations});

uicontrol(hsp6,...
    'Style','PushButton',...
    'Units','normalized',...
    'String','About',...
    'Position',[0.65,0.87,0.30,0.10],...
    'CallBack',{@aboutDiffEquations});

diffequations = uicontrol(hsp6,...
    'Units','normalized',...
    'Position',[0.05,0.03,0.9,0.82],...
    'Style','edit',...
    'Max',100,...
    'Enable','inactive',...plot
    'String','');

% -------------------------- Main -----------------------------

uicontrol(main,...
    'Style','PushButton',...
    'Units','normalized',...
    'String','Process',...
    'Position',[0.015,0.87,0.98,0.10],...
    'CallBack',{@process});

uicontrol(main,...
    'Style','PushButton',...
    'Units','normalized',...
    'String','Plot Output Time Course',...
    'Position',[0.015,0.77,0.98,0.10],...
    'CallBack',{@plotOutputSpeciesVSTime_Button});

uicontrol(main,...
    'Style','PushButton',...
    'Units','normalized',...
    'String','Plot Input/Output Time Course',...
    'Position',[0.015,0.67,0.98,0.10],...
    'CallBack',{@plotGeneralSpeciesVSTime});

uicontrol(main,...
    'Style','PushButton',...
    'Units','normalized',...
    'String','Show Fit Errors',...
    'Position',[0.015,0.57,0.98,0.10],...
    'CallBack',{@showFitErrors});

uicontrol(main,...
    'Style','PushButton',...
    'Units','normalized',...
    'String','Save Output to a File',...
    'Position',[0.015,0.47,0.98,0.10],...
    'CallBack',{@saveResultsToFile});

uicontrol(main,...
    'Style','PushButton',...
    'Units','normalized',...
    'String','Save Output Time Course to a File',...
    'Position',[0.015,0.37,0.98,0.10],...
    'CallBack',{@saveOutputTimeSeriesToFile});

uicontrol(main,...
    'Style','PushButton',...
    'Units','normalized',...
    'String','Clean All Output',...
    'Position',[0.015,0.27,0.98,0.10],...
    'CallBack',{@cleanOutput});

uicontrol(main,...
    'Style','PushButton',...
    'Units','normalized',...
    'String','About the Application',...
    'Position',[0.015,0.17,0.98,0.10],...
    'CallBack',{@about});

% ------------ Functions associated with every control option -------------

% -------------------- Input Read Time Course Data ------------------------
% -------------------------------------------------------------------------

% This function reads and validates the time course data
    function ReadTimeCourseData(File)
        try
            %Load file with time course data
            %str = fileread(File);
            %y1 = load(File);
          
            count=0;
            fid=fopen(File);
            firstl=fgetl(fid);
            firstlcell=regexp(firstl,'\s+','split');
            
            for i=1:length(firstlcell)
                if ~isempty(firstlcell{i})
                    count=count+1;
                    header{count}=firstlcell{i};
                end
            end

            fclose(fid);
            y1 = dlmread(File,'',1,0);
            [l1 b1] = size(y1);
            
            %Eliminates time repetitive elements
            [xx,yy]=unique(y1(:,1));
            y2(:,1)=xx;
            y2(:,2:b1)=y1(yy,2:b1);
            y1=y2;
            [l2 b2] = size(y1);
            
            if(count~=(b1-1))
                uiwait(msgbox('ERROR LOADING TIME COURSE DATA: HEADER LENGTH MUST BE EQUAL TO THE NUMBER OF CHEMICAL SPECIES...','Problem','modal'));
                File1='';
            else
                
                T{1} = y1(:,1);
                Y{1} = y1(:,2:b2);
                
                % Shows the header in the time course data window
                % aux1='';
                % for i=1:b-1
                %    res=sprintf('\t\t  %s',header{i});
                %    aux1=strcat(aux1,res);
                % end
                % str2{1}=aux1;
                 
                aux2='';
                for i=1:b2
                    aux2=strcat(aux2,'%3.2f \t');
                end
                for i=1:l2
                    str2{i}=sprintf(aux2,y1(i,:));
                end

                File1=File;
                NSpecies = b2-1;
                set(timecourse, 'String', str2);
            end
            
        catch
            uiwait(msgbox('ERROR LOADING TIME COURSE DATA: NON NUMERIC CHARACTERS ARE NOT ALLOWED...','Problem','modal'));
            File1='';
        end
    end

% This function plots Species Versus Time from Input
    function plotInputSpeciesVSTime_Button(varargin)
        if not(strcmp(File1,''))
            handle=msgbox('PROCESSING...','Please Wait','modal');
            scrsz = get(0,'ScreenSize');
            figure('Position',[1 scrsz(4)/2 scrsz(3)/2 scrsz(4)/2]);
            close(handle);
            plotInputSpeciesVSTime();
        else
            msgbox('YOU MUST INTRODUCE VALID TIME COURSE DATA FIRST...','Problem','modal');
        end
    end

    function plotInputSpeciesVSTime()
        plotSpeciesVSTime(T{1},Y{1},'o');
    end

% This function displays information about time course data
    function aboutTimeCourseData(varargin)
        str = fileread('AboutTimeCourseData.txt');
        msgbox(str,'About Time Course Data','help','modal');
    end

% This function cleans the time course data display
    function cleanTimeCourseData(varargin)
        answer = questdlg('ARE YOU SURE YOU WANT TO CLEAN THE TIME COURSE DATA ?', ...
            'Confirm', ...
            'Yes', 'No', 'No');
        if (strcmp(answer,'Yes'))
            File1='';
            set(timecourse,'String','');
        end
    end

% ------------------------- Input Read Reactions Data ---------------------
% -------------------------------------------------------------------------

% This functions reads and validates the reactions data
    function ReadReactionsData(File)
        [str ret line]=ReadReactions(File);
        if (ret==0)
            set(reactions, 'String', str);
            File2=File;
        else
            if (ret==-1)
                uiwait(msgbox('REACTIONS FILE NOT FOUND OR PERMISSION DENIED...','Error loading reactions','modal'));
            end
            if (ret==-2)
                uiwait(msgbox('NUMBER OF MOLECULES NOT ALLOWED IN REACTION...','Error loading reactions','modal'));
            end
            if (ret==-3)
                uiwait(msgbox('SPECIES IDENTIFIER GREATER THAN NUMBER OF SPECIES AVAILABLE...','Error loading reactions','modal'));
            end
            if (ret==-4)
                uiwait(msgbox('REACTION SYMBOL -> EXPECTED...','Error loading reactions','modal'));
            end
            if (ret==-5)
                uiwait(msgbox('CHARACTER NOT ALLOWED...','Error loading reactions','modal'));
            end    
            if (ret==-6)
                uiwait(msgbox('EMPTY FILE...','Error loading reactions','modal'));
            end  
            File2='';
        end

    end

% this functions obtains the position of an element in a cell
    function pos=getPos(matchstr,ch)
        for pos=1:length(matchstr)
            if (strcmp(matchstr{pos},ch))
                break;
            end
        end
    end

% This functions manages the data
    function [str ret line]=ReadReactions(File)
        str = fileread(File);
        fid = fopen(File,'r');
        if (fid==-1)
            ret=fid;
            return;
        end

        line=0;
        while 1
            tline = fgetl(fid);
            if ~ischar(tline) break; end;
            if ~strcmp(tline,'')
                line=1;
                new_line=regexprep(tline,'[\s]','');
                new_line=upper(new_line);
                res=regexp(new_line,'[^ X - > + 1-9]','match');
                if (length(res)<=1)
                    res = strsplit('->',new_line);
                    if (length(res) ~= 1)
                        [matchstr splitstr] = regexp(new_line, '[-> X +]', 'match', 'split');
                        if (~isempty(matchstr))
                            pos=getPos(matchstr,'>');
                            elms_react=pos-1;
                            elms_prod=length(splitstr)-pos;
                            aux=[elms_react elms_prod];
                            for j=1:2
                                if (aux(j) > 1)
                                    for i=1:2:aux(j);
                                        if (j==1) value=splitstr{i}; else value=splitstr{pos+i}; end;
                                        if ((not(strcmp(value,''))) && (((str2num(value)) < 0) || ((str2num(value)) > 2)))
                                            ret=-2;
                                            fclose(fid);
                                            return;
                                        end
                                        if (j==1) value=splitstr{i+1}; else value=splitstr{pos+i+1}; end;
                                        if ((not(strcmp(value,''))) && (((str2num(value)) < 1) || ((str2num(value)) > NSpecies)))
                                            ret=-3;
                                            fclose(fid);
                                            return;
                                        end
                                    end
                                end
                            end
                        end
                    else
                        ret=-4;
                        fclose(fid);
                        return;
                    end
                else
                    ret=-5;
                    fclose(fid);
                    return;
                end
                line=line+1;
            end
        end
        
        if (line==0)
            ret=-6;
            fclose(fid);
            return;
        end
        
        ret=0;
    end

% This function displays information about reactions data
    function aboutReactionsData(varargin)
        str = fileread('AboutNonPossibleReactions.txt');
        msgbox(str,'About Non-possible reactions','help','modal');
    end

% This function cleans the reactions data display
    function cleanReactionsData(varargin)
        answer = questdlg('ARE YOU SURE YOU WANT TO CLEAN THE REACTIONS DATA ?', ...
            'Confirm', ...
            'Yes', 'No', 'No');
        if (strcmp(answer,'Yes'))
            File2='';
            set(reactions,'String','');
        end
    end

% ---------------------Input Information Criteria -------------------------
% -------------------------------------------------------------------------

% This function displays information about the information criteria
    function aboutIC(varargin)
        str = fileread('AboutInformationCriteria.txt');
        msgbox(str,'About Information Criteria','help','modal');
    end

% ---------------------Input Information about Interactions----------------
% -------------------------------------------------------------------------

% This function displays information about Interactions
    function aboutInteract(varargin)
        str = fileread('AboutReactionOrder.txt');
        msgbox(str,'About Reaction Order','help','modal');
    end

% ---------------------Input Information about Molecularity----------------
% -------------------------------------------------------------------------

% This function displays information about Molecularity
    function aboutMolec(varargin)
        str = fileread('AboutMolecularity.txt');
        msgbox(str,'About Molecularity','help','modal');
    end

% ----------------------------- MAIN --------------------------------------
% -------------------------------------------------------------------------

% This function displays general information about the application
    function about(varargin)
        str = fileread('AboutMIKANA.txt');
        msgbox(str,'About MIKANA','help','modal');
    end

% This is the main function (calls MIKANA)
    function varargout = process(obj,event,varargin)
        if not (strcmp(File1,''))
            answer = questdlg('ARE YOU SURE YOU WANT TO PROCESS THE DATA ?', ...
                'Confirm', ...
                'Yes', 'No', 'Yes');
            if (strcmp(answer,'Yes'))
                % check information about the criteria selection
                if (get(p1,'Value')==1)
                    ICselection='Empirical';
                elseif (get(p2,'Value')==1)
                    ICselection='Akaike';
                else
                    ICselection='Bayesian';
                end

                % check information about the interactions
                if (get(pp1,'Value')==1)
                    Bimolecular=0;
                else
                    Bimolecular=1;
                end

                % check information about the number of molecules
                if (get(ppp1,'Value')==1)
                    Molecules=1;
                else
                    Molecules=2;
                end

                %% main call to MIKANA
                handle=msgbox('PROCESSING...','Please Wait','modal');
                [used_reactions_res predicted_reactions_res diff_equations_res Errors] = mikanaExec(T, Y, File2, ICselection, Bimolecular, Molecules);
                close(handle);
                
                used_reactions={'','',''};
                used_reactions_index=1;
                used_reactions{1}=used_reactions_res;
                
                predicted_reactions={'','',''};
                predicted_reactions_index=1;
                predicted_reactions{1}=predicted_reactions_res;
                
                diff_equations={'','',''};
                diff_equations_index=2;
                diff_equations{1}=diff_equations_res;
               
                [l1 c1] = size(used_reactions{1});
                [l2 c2] = size(predicted_reactions{1});
                [l3 c3] = size(diff_equations{1});
                if ((c1 > 0) && (c2 > 0) && (l3 > 0))
                    msgbox('JOB COMPLETED...','Success','modal');    
                else
                    msgbox('NO REACTION MECHANISM WAS FOUND...','Warning','modal');
                end
           
                set(usedreactions,'String', used_reactions{1});     
                set(predictedreactions,'String', predicted_reactions{1});
                generate_second_view_diff();
                set(diffequations,'String', diff_equations{2});
                %set(errors,'String', Errors);
                %set(output,'Visible','On');
            end
        else
            msgbox('YOU MUST INPUT VALID TIME COURSE DATA...','Problem','modal');
        end
    end

% --------------------------Output Used Reactions -------------------------
% -------------------------------------------------------------------------

% This function changes the view about used reactions
    function changeViewUsedReactions(varargin)
        % build used reactions

        if ~(isempty(used_reactions{1}))
            used_reactions_index=used_reactions_index+1;
            if (used_reactions_index==4)
                used_reactions_index=1;
            end

            if (isempty(used_reactions{used_reactions_index}))
                [l1 c1] = size(used_reactions{1});
                aux1={};
                for j=1:c1
                    str=used_reactions{1}{j};
                    str=regexprep(str, '+ 0 X\[0\]', '');
                    str=regexprep(str, '0 X\[0\]', '');
                    if (used_reactions_index==3)
                        for i=1:NSpecies
                            str_rep=strcat('X\[',num2str(i),'\]');
                            str=regexprep(str,str_rep,header{i});
                        end
                    end
                    aux1{1}{j}=str;
                end
                used_reactions{used_reactions_index}=aux1{1};
            end

            set(usedreactions,'String', used_reactions{used_reactions_index});
        end
    end

% This function displays information about used reactions
    function aboutUsedReactions(varargin)
        str = fileread('AboutUsedReactions.txt');
        msgbox(str,'About Used reactions','help','modal');
    end

% This function cleans the used reactions display
    function cleanUsedReactions(varargin)
        answer = questdlg('ARE YOU SURE YOU WANT TO CLEAN THE USED REACTIONS DATA ?', ...
            'Confirm', ...
            'Yes', 'No', 'No');
        if (strcmp(answer,'Yes'))
            used_reactions={'','',''};
            set(usedreactions,'String','');
        end
    end

% --------------------------Output Predicted Reactions --------------------
% -------------------------------------------------------------------------

% This function changes the view about predicted reactions
    function changeViewPredictedReactions(varargin)
        % build predicted reactions

        if ~(isempty(predicted_reactions{1}))
            predicted_reactions_index=predicted_reactions_index+1;
            if (predicted_reactions_index==4)
                predicted_reactions_index=1;
            end
            
            if (isempty(predicted_reactions{predicted_reactions_index}))
                [l1 c1] = size(predicted_reactions{1});
                aux1={};
                for j=1:c1
                    str=predicted_reactions{1}{j};
                    str=regexprep(str, '+ 0 X\[0\]', '');
                    str=regexprep(str, '0 X\[0\]', '');
                    if (predicted_reactions_index==3)
                        for i=1:NSpecies
                            str_rep=strcat('X\[',num2str(i),'\]');
                            str=regexprep(str,str_rep,header{i});
                        end
                    end
                    aux1{1}{j}=str;
                end
                predicted_reactions{predicted_reactions_index}=aux1{1};
            end

            set(predictedreactions,'String', predicted_reactions{predicted_reactions_index});
        end
    end

% This function displays information about the predicted reactions
    function aboutPredictedReactions(varargin)
        str = fileread('AboutPredictedReactions.txt');
        msgbox(str,'About Predicted reactions','help','modal');       
    end

% This function cleans the predicted reactions display
    function cleanPredictedReactions(varargin)
        answer = questdlg('ARE YOU SURE YOU WANT TO CLEAN THE PREDICTED REACTIONS DATA ?', ...
            'Confirm', ...
            'Yes', 'No', 'No');
        if (strcmp(answer,'Yes'))
            predicted_reactions={'','',''};
            set(predictedreactions,'String','');
        end
    end

% --------------------------Output Differential Equations -----------------
% -------------------------------------------------------------------------

% This function changes the view about predicted reactions
    function changeViewDiffEquations(varargin)
        % build diff equations

        if ~(isempty(diff_equations{1}))
            diff_equations_index=diff_equations_index+1;
            if (diff_equations_index==4)
                diff_equations_index=2;
            end

            if (isempty(diff_equations{diff_equations_index}))
                [l1 c1] = size(diff_equations{2});
                aux1={};
                for j=1:c1
                    str=diff_equations{2}{j};
                    for i=1:NSpecies
                        str_rep=strcat('X''\(',num2str(i),'\)');
                        str=regexprep(str,str_rep,strcat(header{i},''''));
                        str_rep=strcat('X\(',num2str(i),'\)');
                        str=regexprep(str,str_rep,header{i});
                    end
                    aux1{j}=str;
                end
                diff_equations{diff_equations_index}=aux1;
            end

            set(diffequations,'String', diff_equations{diff_equations_index});
        end
    end

% This function displays information about the predicted differential
% equations
    function aboutDiffEquations(varargin)
        str = fileread('AboutDifferentialEquations.txt');
        msgbox(str,'About Differential Equations','help','modal');
    end

% This function cleans the differential equations display
    function cleanDiffEquations(varargin)
        answer = questdlg('ARE YOU SURE YOU WANT TO CLEAN THE DIFFERENTIAL EQUATIONS DATA ?', ...
            'Confirm', ...
            'Yes', 'No', 'No');
        if (strcmp(answer,'Yes'))
            diff_equations={'','',''};
            set(diffequations,'String','');
        end
    end

% --------------------------Output Differential Equations -----------------
% -------------------------------------------------------------------------

% This function displays information about the Errors
    function aboutErrors(varargin)
        str = fileread('AboutErrors.txt');
        msgbox(str,'About Errors','help','modal');
    end

% This function cleans the errors display
    function cleanErrors(varargin)
        answer = questdlg('ARE YOU SURE YOU WANT TO CLEAN THE ERRORS DATA ?', ...
            'Confirm', ...
            'Yes', 'No', 'No');
        if (strcmp(answer,'Yes'))
            set(errors,'String','');
        end
    end

% -------------------------- Other Output control functions ---------------
% -------------------------------------------------------------------------

% This function shows the fit errors
    function showFitErrors(varargin)
        [l1 c1] = size(diff_equations{1});
        if (l1 > 0)
            for i=1:NSpecies
                txt = sprintf('%s: %d',header{i},Errors(i));
                wrt{i}=txt;
            end
            msgbox(wrt,'Errors','modal');
        else
            msgbox('NO OUTPUT DIFFERENTIAL EQUATIONS EXIST...','Problem','modal');
        end
    end

% This function plots Species Versus Time from Output
    function plotOutputSpeciesVSTime_Button(varargin)
        [l1 c1] = size(diff_equations{1});
        if (l1 > 0)
            handle=msgbox('PROCESSING...','Please Wait','modal');
            scrsz = get(0,'ScreenSize');
            figure('Position',[1 scrsz(4)/2 scrsz(3)/2 scrsz(4)/2])
            plotOutputSpeciesVSTime();
            close(handle);
        else
            msgbox('NO OUTPUT DIFFERENTIAL EQUATIONS EXIST...','Problem','modal');
        end
    end

    function plotOutputSpeciesVSTime()
        [TR YR] = solveDiffEquations();
        plotSpeciesVSTime(TR,YR,'-');
    end

% This function plots Species Versus Time
    function plotGeneralSpeciesVSTime(varargin)
        if not(strcmp(File1,''))
            [l1 c1] = size(diff_equations{1});
            if (l1 > 0)
                handle=msgbox('PROCESSING...','Please Wait','modal');
                scrsz = get(0,'ScreenSize');
                figure('Position',[1 scrsz(4)/2 scrsz(3)/2 scrsz(4)/2])
                plotInputSpeciesVSTime();
                hold on;
                plotOutputSpeciesVSTime();
                close(handle);
            else
                msgbox('NO OUTPUT DIFFERENTIAL EQUATIONS EXIST...','Problem','modal');
            end
        else
            msgbox('YOU MUST INPUT VALID TIME COURSE DATA FIRST...','Problem','modal');
        end
    end

% This function solves the differential equations
    function [TR YR] = solveDiffEquations()
        function dX = solODE(t,X)
            dX = zeros(NSpecies,1); % a column vector
            for i=1:NSpecies
                eval(strcat(diff_equations{1}{i},';'));
            end
        end

        initConds=[];
        for i=1:NSpecies
            initConds=[initConds Y{1}(1,i)];
        end

        [TR YR] = ode45(@solODE,[T{1}(1) T{1}(length(T{1}))],initConds);
    end

% This function saves all the results to a file
    function saveResultsToFile(varargin)
        [l1 c1] = size(used_reactions{1});
        [l2 c2] = size(predicted_reactions{1});
        [l3 c3] = size(diff_equations{1});

        if ((c1 > 0) || (c2 > 0) || (l3 > 0))
            answer = questdlg('DO YOU WISH TO SAVE THE OUTPUT TIME COURSE DATA AS WELL ?', ...
                'Confirm', ...
                'Yes', 'No', 'Yes');

            [file,path] = uiputfile('RESULTS.TXT','Save file name');
            if not(file==0)
                filestr=strcat(path,file);
                fid2 = fopen(filestr,'w');
                if (fid2==-1)
                    msgbox('THERE WAS A PROBLEM CREATING A TEMPORARY FILE IN THE SYSTEM...','Problem','modal');
                    return;
                end

                fprintf(fid2,'\n ---------- MIKANA Output ---------- \n');
                fprintf(fid2,'\nThis file was generated on %s\n', datestr(now));
                saveInputOptionsToFile(fid2);

                fprintf(fid2,'\n%s\n','----- Used Reactions -----');
                for i=1:c1
                    fprintf(fid2,'%s\n',used_reactions{used_reactions_index}{i});
                end

                fprintf(fid2,'\n%s\n','----- Predicted Reactions -----');
                for i=1:c2
                    fprintf(fid2,'%s\n',predicted_reactions{predicted_reactions_index}{i});
                end

                fprintf(fid2,'\n%s\n','----- Differential Equations -----');
                for i=1:l3
                    fprintf(fid2,'%s\n',diff_equations{diff_equations_index}{i});
                end

                fprintf(fid2,'\n%s\n','----- Errors -----');
                for i=1:NSpecies
                    txt = sprintf('%s: %d',header{i},Errors(i));
                    fprintf(fid2,'%s\n',txt);
                end

                if (strcmp(answer,'Yes'))
                    saveTimeSeriesToFile(fid2);
                end

                txt = strcat(file,' WAS CREATED IN THE DESIGNATED PATH...');
                msgbox(txt,'Success','modal');
                fclose(fid2);
            end
        else
            msgbox('INPUT DATA NEED TO BE PROCESSED FIRST...','Problem','modal');
        end
    end

% This function saves output time series results to a file
    function saveOutputTimeSeriesToFile(varargin)
        [l3 c3] = size(diff_equations{1});

        if (l3 > 0)
            [file,path] = uiputfile('TIMECOURSE.TXT','Save file name');
            if not(file==0)
                filestr=strcat(path,file);
                fid2 = fopen(filestr,'w');
                if (fid2==-1)
                    msgbox('THERE WAS A PROBLEM CREATING A TEMPORARY FILE IN THE SYSTEM...','Problem','modal');
                    return;
                end

                fprintf(fid2,'\n ---------- MIKANA Time Course Output ---------- \n');
                fprintf(fid2,'\nThis file was generated on %s\n\n', datestr(now));
                saveTimeSeriesToFile(fid2);
                txt = strcat(file,' WAS CREATED IN THE DESIGNATED PATH...');
                msgbox(txt,'Success','modal');
                fclose(fid2);
            end
        else
            msgbox('NO OUTPUT DIFFERENTIAL EQUATIONS EXIST...','Problem','modal');
        end

    end

% -------------------------- General Functions ----------------------------
% -------------------------------------------------------------------------

% This functions corrects the way differential equations are written
    function generate_second_view_diff()
        res={};
        for i=1:length(diff_equations{1})
           res{i}=regexprep(diff_equations{1}{i},'(dX)','X''');
        end
        diff_equations{2}=res;
    end

% This function saves the input options to a file
    function saveInputOptionsToFile(fileHandle)
        if (Bimolecular==0)
            Bimtext='First Order';
        else
            Bimtext='Second Order';
        end
        if (Molecules==1)
            Moltext='Uni-Molecular';
        else
            Moltext='Bi-Molecular';
        end
        fprintf(fileHandle,'\n\nMIKANA Input options: \n\n     ICselection: %s\n', ICselection);
        fprintf(fileHandle,'     Reaction Order: %s \n', Bimtext);
        fprintf(fileHandle,'     Molecularity: %s \n', Moltext);
    end

% This function saves the output time series to a file
    function saveTimeSeriesToFile(fileHandle)
        fprintf(fileHandle,'\n%s\n','----- Generated Time Course Data -----');
        [l4 c4] = size(YR);
        if (l4 == 0)
            [TR YR] = solveDiffEquations();
        end

        [l4 c4] = size(YR);
        for i=1:l4
            fprintf(fileHandle,'\n%d ',TR(i));
            for j=1:c4
                fprintf(fileHandle,'%d ',YR(i,j));
            end
        end
    end

% This functions plots species concentration over time
    function plotSpeciesVSTime(X,Y,type)
        plot(X,Y,type,'LineWidth',5);
        set(gca,'FontSize',18,'Fontweight','bold');
        if (Bimolecular==0)
            Bimtext='First Order';
        else
            Bimtext='Second Order';
        end
        if (Molecules==1)
            Moltext='Uni-Molecular';
        else
            Moltext='Bi-Molecular';
        end
        str=sprintf('ICselection: %s, Reaction Order: %s, Molecularity: %s',ICselection,Bimtext,Moltext);
        title(str,'fontweight','b','fontsize',14);
        xlabel('Time','fontweight','b','fontsize',18);
        ylabel('Chemical Species','fontweight','b','fontsize',18);
        
        aux=cell(1,NSpecies);
        for i=1:NSpecies
            aux{i}=header{i};
        end
        
        legend(aux);
    end

% This function cleans all output
    function cleanOutput(varargin)
        [l1 c1] = size(used_reactions{1});
        [l2 c2] = size(predicted_reactions{1});
        [l3 c3] = size(diff_equations{1});

        if ((c1 > 0) || (c2 > 0) || (l3 > 0))
            answer = questdlg('ARE YOU SURE YOU WANT TO CLEAN ALL OUTPUT DATA ?', ...
                'Confirm', ...
                'Yes', 'No', 'No');
            if (strcmp(answer,'Yes'))
                used_reactions={'','',''};
                predicted_reactions={'','',''};
                diff_equations={'','',''};
                set(usedreactions,'String','');
                set(predictedreactions,'String','');
                set(diffequations,'String','');
            end
        else
            msgbox('NO OUPTUT DATA EXISTS TO BE CLEAN...','Problem','modal');
        end
    end

% This function reads a file from the filesystem
    function varargout = open_Callback(h, handles, varargin)
        [file_name, mach_path] = uigetfile( ...
            {'*.txt', 'All TEXT-Files (*.txt)'; ...
            '*.dat', 'All TEXT-Files (*.dat)'; ...
            '*.*','All Files (*.*)'}, ...
            'Select File');

        % If "Cancel" is selected then return
        if isequal([file_name,mach_path],[0,0])
            return
            % Otherwise construct the fullfilename and Check and load the file
        else
            File = fullfile(mach_path,file_name);
        end

        %  The header information is read in as a one dimentional array
        %  [Header,count] = fread(input_fid,14,'uint');
        handles.mp=mach_path;
        handles.fn=file_name;
        %Create date and time labels
        guidata(h,handles);
        file_name=handles.fn;
        filename=file_name;
        length_fn=length(filename);
        st_pt=length_fn+1-4;
        file_ext=filename(st_pt:length_fn);
        mpath=mach_path;
        pathloc=[mpath file_name];

        option=varargin{1};
        check_file=(strcmp(file_ext,'.txt') || (strcmp(file_ext,'.dat')));
        if ((option==1) && check_file)
            ReadTimeCourseData(File);
        end
        if ((option==2) && check_file)
            ReadReactionsData(File);
        end
    end

% Redefines the closereq function
    function my_closereq(src,evnt)
        delete(gcf);
    end

end
